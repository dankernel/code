/*
[The "BSD licence"]
Copyright (c) 2005-2007 Kunle Odutola
Copyright (c) 2007 Johannes Luber
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:
1. Redistributions of source code MUST RETAIN the above copyright
   notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form MUST REPRODUCE the above copyright
   notice, this list of conditions and the following disclaimer in 
   the documentation and/or other materials provided with the 
   distribution.
3. The name of the author may not be used to endorse or promote products
   derived from this software without specific prior WRITTEN permission.
4. Unless explicitly state otherwise, any contribution intentionally 
   submitted for inclusion in this work to the copyright owner or licensor
   shall be under the terms and conditions of this license, without any 
   additional terms or conditions.

THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/


namespace Antlr.Runtime.Tree {
	using System;
	using System.Collections.Generic;

	/// <summary>
	/// </summary>
	/// <remarks></remarks>
	/// <example></example>
	public class RewriteRuleTokenStream : RewriteRuleElementStream {
		public RewriteRuleTokenStream(ITreeAdaptor adaptor, string elementDescription)
			: base(adaptor, elementDescription) {
		}

		/// <summary>
		/// Create a stream with one element
		/// </summary>
		public RewriteRuleTokenStream(
			ITreeAdaptor adaptor,
			string elementDescription,
            object oneElement
		) : base(adaptor, elementDescription, oneElement) {
		}

		/// <summary>Create a stream, but feed off an existing list</summary>
		public RewriteRuleTokenStream(
			ITreeAdaptor adaptor,
			string elementDescription,
            IList<object> elements
		) : base(adaptor, elementDescription, elements) {
		}

		/// <summary>
		/// Get next token from stream and make a node for it.
		/// </summary>
		/// <remarks>
		/// ITreeAdaptor.Create() returns an object, so no further restrictions possible.
		/// </remarks>
		public virtual object NextNode() {
            return adaptor.Create((IToken) NextTree());
		}

        public virtual IToken NextToken() {
            return (IToken) NextTree();
		}

		/// <summary>
		/// 
		/// Don't convert to a tree unless they explicitly call NextTree().
		/// This way we can do hetero tree nodes in rewrite.
		/// </summary>
        override protected object ToTree(object el) {
			return el;
		}

        protected override object Dup(object el) {
            throw new NotSupportedException("dup can't be called for a token stream.");
        }
    }
}
