/*
 * =====================================================================================
 *
 *       Filename:  errno.h
 *
 *    Description:  error number
 *
 *        Version:  1.0
 *        Created:  2014년 08월 18일 02시 50분 32초
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         author:   (), 
 *   organization:  
 *
 * =====================================================================================
 */

#define EARG_NULL 0x0000001
#define EFAIL_FUNC 0x0000002

