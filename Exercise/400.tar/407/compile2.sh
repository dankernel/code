gcc -finput-charset=UTF-8 -o main2 main2.c -lm
./main2
