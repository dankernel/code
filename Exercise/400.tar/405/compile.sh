gcc -finput-charset=UTF-8 -o main main.c -lm
./main
