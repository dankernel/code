var searchData=
[
  ['offsetof',['offsetof',['../dk__kernel_8h.html#ad89ebe5fe5ad08c683f0871118ea8e2f',1,'offsetof():&#160;dk_kernel.h'],['../dk__list_8h.html#afd049f7ad59dbe455f460807475c2841',1,'offsetof():&#160;dk_list.h']]]
];
