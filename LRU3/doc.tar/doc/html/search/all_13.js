var searchData=
[
  ['w_5fcache',['w_cache',['../structdk__tree.html#ab968d09f4098a59419b509bce61debcb',1,'dk_tree']]],
  ['workload',['workload',['../structworkload.html',1,'']]],
  ['write',['write',['../structcache__mem.html#adb5a0315176779908235c7ed3e41ec57',1,'cache_mem::write()'],['../lru_8h.html#aa10f470e996d0f51210d24f442d25e1e',1,'WRITE():&#160;lru.h']]]
];
