var searchData=
[
  ['main',['main',['../main_8c.html#a0ddf1224851353fc92bfbff6f499fa97',1,'main.c']]],
  ['main_2ec',['main.c',['../main_8c.html',1,'']]],
  ['max',['max',['../structcache__mem.html#aca41dfab3073387e6c6063457a17f616',1,'cache_mem']]],
  ['max_5fbuff_5fsize',['MAX_BUFF_SIZE',['../file__read_8h.html#a212979f5fc9dcf0a420e90b9b21d780a',1,'file_read.h']]],
  ['mb',['MB',['../lru_8h.html#aa6b38d492364d98453284934ed7caee9',1,'lru.h']]],
  ['mutex',['mutex',['../structanalysis__arg.html#a5af66e583b346de25aee6ab4acaa91a7',1,'analysis_arg']]]
];
