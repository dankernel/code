var searchData=
[
  ['max_5fbuff_5fsize',['MAX_BUFF_SIZE',['../file__read_8h.html#a212979f5fc9dcf0a420e90b9b21d780a',1,'file_read.h']]],
  ['mb',['MB',['../lru_8h.html#aa6b38d492364d98453284934ed7caee9',1,'lru.h']]]
];
