var searchData=
[
  ['r',['r',['../structdk__tree.html#a5d989a0efeadbc970750f1ac8ad4018e',1,'dk_tree::r()'],['../structdk__tnode.html#a13392f297542ba6ec06da4e389ef3d7f',1,'dk_tnode::r()']]],
  ['r_5fcache',['r_cache',['../structdk__tree.html#ae1a363a68dda726e3010e6766057dbbe',1,'dk_tree']]],
  ['read',['read',['../structcache__mem.html#af64061b621392a1872f5cb92dde7dc7c',1,'cache_mem::read()'],['../lru_8h.html#ada74e7db007a68e763f20c17f2985356',1,'READ():&#160;lru.h']]],
  ['read_5fcolumn',['read_column',['../lru_8h.html#a30c6287565ac5b2d5161a0642c59888a',1,'lru.h']]],
  ['read_5ffile',['read_file',['../code__analyze_8h.html#a40c5275f63bcc1394af4771780714285',1,'code_analyze.h']]],
  ['read_5fnext_5fline',['read_next_line',['../file__read_8h.html#a744a461bab4a6c47c93cc697a3464761',1,'file_read.h']]],
  ['read_5ftoken_5fline',['read_token_line',['../file__read_8h.html#a6ca2c59b960803be2495125fd8ad9ee9',1,'file_read.h']]],
  ['read_5fworkload',['read_workload',['../lru_8h.html#a23bbdc4f3ff2ccbf5aaf6a2cc5a584b8',1,'lru.h']]],
  ['report_5fcm',['report_cm',['../lru_8h.html#a987168b3169b138b36aad5903e5ce4ee',1,'lru.h']]],
  ['respone',['respone',['../structworkload.html#a8de001cbb458db8f4502435a2a6c2030',1,'workload']]],
  ['result',['result',['../structfile__info.html#a0b17a1cbdb96ab198326c6073c862fe1',1,'file_info']]],
  ['root',['root',['../structdk__tree.html#a6a5c48e2ff2494e10aafd1d0bc9d5992',1,'dk_tree']]],
  ['row',['row',['../structhash__table.html#a634ff501f78f223799d4923fbcbbf30d',1,'hash_table']]],
  ['run_5fcache',['run_cache',['../lru_8h.html#a3d667614dda729b6e0491823d5e8b3d1',1,'lru.h']]]
];
