var searchData=
[
  ['offset',['offset',['../structworkload.html#a05766e7402dae7d93f0f6602e4498a36',1,'workload']]],
  ['offsetof',['offsetof',['../dk__kernel_8h.html#ad89ebe5fe5ad08c683f0871118ea8e2f',1,'offsetof():&#160;dk_kernel.h'],['../dk__list_8h.html#afd049f7ad59dbe455f460807475c2841',1,'offsetof():&#160;dk_list.h']]],
  ['open_5ffile',['open_file',['../file__read_8h.html#ae84bfdae0ec7b73cf580228efa76178e',1,'file_read.h']]],
  ['open_5fworkload',['open_workload',['../lru_8h.html#a18d6e93c1f872081867eee56e7d943f7',1,'lru.h']]]
];
